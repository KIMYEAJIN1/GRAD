<?php
	define("DB_HOST", "localhost");
	define("DB_USER", "mood");
	define("DB_PASSWORD", "password");
	define("DB_NAME", "mood");
	define("GOOGLE_API_KEY", "AAAABNYV-pM:APA91bGa4VWqEqEjP7zu2LAzePBxyKVDhc_xYlfx539G9M_HFTVj232ruYLYHLJsG9SLzSntbBMRrwIFlB3VbDbLA2twhf_EQSRq8xJvCT59Zg81MhsI0zLRO0yLKpHmD_GFT84UWjOy");
?>
